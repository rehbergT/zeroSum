#' @name exampleData
#' @title example  data
#' @description This data is used for demonstration
#' purpose / debugging
#' @docType data
#' @usage exampleData
#' @format a \code{RangedData} instance, rows=samples.
#' @source simulated
#' @author simulated
#' @return example data
NULL
