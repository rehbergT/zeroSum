#ifndef LAMBDAMAX_H
#define LAMBDAMAX_H

#include "mathHelpers.h"

#include <R.h>
#include <Rdefines.h>

SEXP lambdaMax( SEXP _X, SEXP _beta0, SEXP );

#endif /* LAMBDAMAX_H */
