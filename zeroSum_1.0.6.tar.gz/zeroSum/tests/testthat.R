library(testthat)
library(zeroSum)

test_check("zeroSum")
